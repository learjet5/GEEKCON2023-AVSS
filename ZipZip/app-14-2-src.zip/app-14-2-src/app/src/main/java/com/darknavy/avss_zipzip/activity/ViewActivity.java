package com.darknavy.avss_zipzip.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.loader.AssetsProvider;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.darknavy.avss_zipzip.R;
import com.darknavy.avss_zipzip.utils.ZipUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class ViewActivity extends AppCompatActivity {

    private static final String TAG = "AVSS-ZipZip";

    private ImageView logoImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        logoImage = findViewById(R.id.logo_image);

        Uri zipUrl = getIntent().getParcelableExtra(Intent.EXTRA_STREAM);
        File destDir = new File(getFilesDir(), "extract_" + new Random().nextInt());
        ZipUtils.createOrExistsDir(destDir);

        if(zipUrl != null) {
            try {
                extractPicture(zipUrl, destDir);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            try {
                InputStream zipStream = getAssets().open("logo.zip");
                ZipUtils.unzipFile(zipStream, destDir);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }


        File imageFile = new File(destDir, "logo.png");
        Bitmap draw = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
        logoImage.setImageBitmap(draw);
    }

    private void extractPicture(Uri zipUrl, File dest) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(zipUrl);
        ZipUtils.unzipFile(inputStream, dest);
    }
}