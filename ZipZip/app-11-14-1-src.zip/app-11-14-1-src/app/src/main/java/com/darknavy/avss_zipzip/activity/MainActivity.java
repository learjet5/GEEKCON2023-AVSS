package com.darknavy.avss_zipzip.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.darknavy.avss_zipzip.R;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static String TAG = "AVSS-ZipZip";
    private Button view_logo_btn;
    private Button open_calc_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view_logo_btn = findViewById(R.id.view_logo_btn);
        open_calc_btn = findViewById(R.id.open_calc_btn);

        view_logo_btn.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), ViewActivity.class);
            startActivity(intent);
        });

        open_calc_btn.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), CalcActivity.class);
            intent.putExtra("calc", "1337");
            startActivity(intent);
        });

        Intent internalIntent = getIntent().getParcelableExtra("internal_intent");
        if(internalIntent != null){
            startActivity(internalIntent);
        }
    }

}