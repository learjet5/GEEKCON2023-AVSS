

#include <string.h>
#include <jni.h>
#include <stdlib.h>
#include "android/log.h"
#include <malloc.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>

#define DEBUG 0

#define TAG "HELLO_JNI"
#define LOGD(...) if(DEBUG) { __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__); }
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL, TAG, __VA_ARGS__)

#define nullptr NULL


#define ARRAY_SIZE 50
struct mystruct *chunklist[ARRAY_SIZE];
unsigned int chunksize[ARRAY_SIZE];
#define MAXSIZE 0x1000

#define KEYSIZE 8
struct mystruct
{
    char key[KEYSIZE];
    unsigned char value[0];
};

int flag = 0;
extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1add(JNIEnv *env, jobject thiz, jint idx, jstring jkey, jint size)
{
    unsigned int realsize = size + KEYSIZE;
    const char *key = env->GetStringUTFChars(jkey, nullptr);
    if (idx >= 0 && idx < ARRAY_SIZE && (unsigned int)size > 0 && (unsigned int)realsize <= MAXSIZE) {
        struct mystruct *p = (struct mystruct *) new char[realsize];
//        memset(p, 0, sizeof(struct mystruct));  // initialize
        strncpy(p->key, (char *)key, KEYSIZE);

        chunklist[idx] = p;
        chunksize[idx] = realsize;

    }
}

extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1edit(JNIEnv *env, jobject thiz, jint idx, jbyteArray jdata)
{
    signed char *data = env->GetByteArrayElements(jdata, nullptr);
    unsigned int size = env->GetArrayLength(jdata);
    if (idx >= 0 && idx < ARRAY_SIZE && chunklist[idx] != 0 && chunksize[idx] != 0)
    {
        if (size > chunksize[idx])
            size = chunksize[idx];
        memcpy(((struct mystruct *)chunklist[idx])->value, data, size); // overflow 8 bytes
    }
}

extern "C" JNIEXPORT jbyteArray JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1show(JNIEnv *env, jobject thiz, jint idx, jint size)
{
    if (idx >= 0 && idx < ARRAY_SIZE && chunklist[idx] != 0 && chunksize[idx] != 0)
    {
        if (size > chunksize[idx])
            size = chunksize[idx];
        jbyteArray bytes = env->NewByteArray(size);
        env->SetByteArrayRegion(bytes, 0, size, (jbyte *)((struct mystruct *)chunklist[idx])->value); // overread 8 bytes
        return bytes;
    }
    else
    {
        jbyteArray bytes = env->NewByteArray(0);
        return bytes;
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1delete(JNIEnv *env, jobject thiz, jint idx)
{
    if (idx >= 0 && idx < ARRAY_SIZE && chunklist[idx] != 0)
    {
        // double free
        free(chunklist[idx]);
        //        chunklist[idx] = 0;
        chunksize[idx] = 0;
    }
}


class FileBase {
public:
    virtual size_t read(void* ptr, size_t size, size_t nmemb) = 0;
    virtual size_t write(const void* ptr, size_t size, size_t nmemb) = 0;
    virtual long tell() = 0;
    virtual int seek(long offset, int origin) = 0;

    virtual ~FileBase() { }
};

class FileIO : public FileBase {
    private:
        FILE* file;
        char openmode;

    public:
        FileIO(const char* filename, const char* mode) {
            file = fopen(filename, mode);
            if (file == nullptr) {
                LOGD("fopen failed");
                return;
            }
            openmode = mode[0];
        }

        ~FileIO() override {
            if (file != nullptr) {
                fclose(file);
            }
        }

        size_t read(void* ptr, size_t size, size_t nmemb) override {
            if (openmode == 'r') {
                return fread(ptr, size, nmemb, this->file);
            }
            else
                return -1;
        }

        size_t write(const void* ptr, size_t size, size_t nmemb) override {
            if (openmode == 'w')
                return fwrite(ptr, size, nmemb, file);
            else
                return -1;
        }

        long tell() override {
            return ftell(file);
        }

        int seek(long offset, int origin) override {
            return fseek(file, offset, origin);
        }
};

#define MODE_READ 0
#define MODE_WRITE 1

FileIO * gfileio;

extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1openfile(JNIEnv *env, jobject thiz, jstring jfilename, jint mode)
{
    const char *filename = env->GetStringUTFChars(jfilename, nullptr);

    FileIO * p;
    if (mode == MODE_READ)
    {
        p = new FileIO(filename, "rb");
    }
    else if (mode == MODE_WRITE)
    {
        p = new FileIO(filename, "wb");
    }
    else
    {
        LOGD("wrong mode");
        return;
    }
    gfileio = p;
    return;
}

extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1writefile(JNIEnv *env, jobject thiz, jbyteArray jdata)
{
    signed char *data = env->GetByteArrayElements(jdata, nullptr);
    unsigned int len = env->GetArrayLength(jdata);
    if (gfileio)
    {
        gfileio->write(data, 1, len);
    }
    else
    {
        LOGD("init first");
    }
}

extern "C" JNIEXPORT jbyteArray JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1readfile(JNIEnv *env, jobject thiz)
{
    if (gfileio)
    {
        gfileio->seek(0, SEEK_END);
        long fileSize = gfileio->tell();
        gfileio->seek(0, SEEK_SET);
        char *ptr = new char[fileSize];
        memset(ptr, 0 , fileSize);
        int readbytes = gfileio->read(ptr, 1, fileSize);
        jbyteArray bytes = env->NewByteArray(fileSize);
        env->SetByteArrayRegion(bytes, 0, fileSize, (jbyte *)ptr);
        return bytes;
    }
    else
    {
        LOGD("init first");
        return env->NewByteArray(0);
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_avss_testallocator_MyJavaScriptInterface_native_1closefile(JNIEnv *env, jobject thiz)
{
    if (gfileio)
    {
        delete gfileio;
        gfileio = nullptr;
    }
    else
    {
        LOGD("open first");
    }
}
