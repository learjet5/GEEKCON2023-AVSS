package com.avss.testallocator;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FlagReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String s = intent.getStringExtra("flag");
        if(s != null) {
            File file = new File(context.getFilesDir(), "flag");
            if (file.exists()) {
                Log.e("FlagReceiver", "Flag exist.");
            } else {
                this.writeFile(file, s);
                Log.e("FlagReceiver", "Received flag.");
            }
        } else {
            Log.e("FlagReceiver", "No flag in intent");
        }
    }

    public void writeFile(File file, String content) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

