package com.avss.testallocator;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;

import java.io.File;

public class MyJavaScriptInterface {
    static {
        System.loadLibrary("hello-jni");
    }

    Context appcontext;

    public MyJavaScriptInterface(Context appcontext) {
        this.appcontext = appcontext;
    }

    private static String hex(byte[] bytes) {
        StringBuilder hexed = new StringBuilder();
        for (byte b : bytes) {
            hexed.append(String.format("%02x", b));
        }
        return hexed.toString();
    }

    private static byte[] unhex(String hexed) {
        byte[] bytes = new byte[hexed.length() / 2];
        for (int i = 0; i < hexed.length(); i += 2) {
            bytes[i / 2] = (byte) Integer.parseInt(hexed.substring(i, i + 2), 16);
        }
        return bytes;
    }

    public native void native_add(int idx, String key, int size);
    public native void native_edit(int idx, byte[] data);
    public native byte[] native_show(int idx, int size);
    public native void native_delete(int idx);
    public native void native_openfile(String filename, int mode);
    public native void native_writefile(byte[] data);
    public native byte[] native_readfile();
    public native void native_closefile();

    @JavascriptInterface
    public void add(int idx, String key, int size) {
        native_add(idx, key, size);
    }
    @JavascriptInterface
    public void edit(int idx, String data) {
        native_edit(idx, unhex(data));
    }
    @JavascriptInterface
    public String show(int idx, int size) {
        byte[] t = native_show(idx, size);
        String a = hex(t);
        return a;
    }
    @JavascriptInterface
    public void delete(int idx) {
        native_delete(idx);
    }
    @JavascriptInterface
    public void openfile(String filename, int mode) {
        File privateDir = this.appcontext.getFilesDir();
        String dir =  privateDir.getAbsolutePath() + "/tmp/";
        File directory = new File(dir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        if (filename.contains("/")) {
            Log.d("MyJavaScriptInterface", "filename contains /");
            return;
        }
        String path = dir + filename;
        native_openfile(path, mode);
    }
    @JavascriptInterface
    public void writefile(String data) {
        native_writefile(unhex(data));
    }
    @JavascriptInterface
    public String readfile() {
        return hex(native_readfile());
    }
    @JavascriptInterface
    public void closefile() {
        native_closefile();
    }
}
