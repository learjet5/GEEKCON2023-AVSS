package com.avss.testallocator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getIntent().hasExtra("url")) {
            String url = getIntent().getStringExtra("url");
            Log.d("MainActivity", "Loading url: "+url);
            Intent intent = new Intent(this, MyWebViewActivity.class);
            intent.putExtra("url", url);
            startActivity(intent);
        } else {
            Log.d("MainActivity", "no url");
        }



    }

}
