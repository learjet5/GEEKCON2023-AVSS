package com.avss.testreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class MyBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG="MyBroadcastReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.avss.testreceiver.GET_FLAG")) {
            readflag(context);
        }
    }

    public static void readflag(Context context) {
        File file = new File(context.getFilesDir(), "flag");

        if (file.exists()) {
            try {
                Log.d(TAG, "Logging flag.");
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    Log.d(TAG, line);
                }
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            Log.d(TAG, "File does not exist.");
        }
    }
}
